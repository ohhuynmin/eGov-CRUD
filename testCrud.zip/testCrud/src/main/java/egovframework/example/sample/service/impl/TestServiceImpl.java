package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.TestDao;
import egovframework.example.sample.service.TestService;
import egovframework.example.sample.vo.TestVo;

@Service
public class TestServiceImpl implements TestService{
	
    @Autowired
    private TestDao testDao;


    @Override
    public List<TestVo> selectTestList() throws Exception {
        return testDao.selectTestList();
    }
    @Override
    public TestVo selectTest(TestVo testVo) throws Exception {
        return testDao.selectTest(testVo);
    }
    @Override
    public void addTest(TestVo testVo) throws Exception{
    	testDao.addTest(testVo);
    }
    @Override
    public void updateTest(TestVo testVo) throws Exception{
    	testDao.updateTest(testVo);
    }
    @Override
    public void deleteTest(TestVo testVo) throws Exception{
    	testDao.deleteTest(testVo);
    }
    @Override
    public List<TestVo> searchTest(TestVo testVo) throws Exception{
    	return testDao.searchTest(testVo);
    }
    @Override
    public int countTest(TestVo testVo) throws Exception{
    	return testDao.countTest(testVo);
    }
}
