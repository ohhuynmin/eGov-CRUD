package egovframework.example.sample.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FileDownloadController {
	
	@RequestMapping(value="fileDownload.do")
	public void fileDownload(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String filename = req.getParameter("fileName");
        String realFilepath = "";
        System.out.println(filename);
        
        try {
        	String browser = req.getHeader("User-Agent");
        	if (browser.contains("MSIE") || browser.contains("Trident") || browser.contains("Chrome")) {
                filename = URLEncoder.encode(filename, "UTF-8");
            } else {
                filename = new String(filename.getBytes("UTF-8"), "ISO-8859-1");
            }
        }catch(UnsupportedEncodingException e) {
        	e.printStackTrace();
        }
        realFilepath = "/usr/local/upload/" + filename;
        File file = new File(realFilepath);
        if (!file.exists()) {
            return;
        }
     // 파일명 지정
        res.setContentType("application/octer-stream");
        res.setHeader("Content-Transfer-Encoding", "binary");
        res.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
 
        try {
            OutputStream os = res.getOutputStream();
            FileInputStream fis = new FileInputStream(realFilepath);
            
            
            int cnt = 0;
            byte[] bytes = new byte[512];	 //512bytes씩 끊어서 전송 
 
            while ((cnt = fis.read(bytes)) != -1) {
                os.write(bytes, 0, cnt);
            }
            fis.close();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
