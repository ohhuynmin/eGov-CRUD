package egovframework.example.sample.service;

import egovframework.example.sample.vo.UserVo;

public interface UserMapper {
	UserVo login(UserVo userVo) throws Exception;
	void signup(UserVo userVo) throws Exception;
	void signout(UserVo userVo) throws Exception;
	UserVo findPwd(UserVo userVo) throws Exception;
	void updateUser(UserVo userVo) throws Exception;
}
