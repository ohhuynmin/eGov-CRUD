package egovframework.example.sample.service;
import java.util.List;

import egovframework.example.sample.vo.TestVo;


public interface TestMapper {
	List<TestVo> selectTestList() throws Exception;
	List<TestVo> searchTest(TestVo testVo) throws Exception;
	TestVo selectTest(TestVo testVo) throws Exception;
	TestVo testUpdate(TestVo testVo) throws Exception;
	void addTest(TestVo testVo) throws Exception;
	void updateTest(TestVo testVo) throws Exception;
	void deleteTest(TestVo testVo) throws Exception;
	int countTest(TestVo testVo) throws Exception;
}
