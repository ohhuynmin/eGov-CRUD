package egovframework.example.sample.dao;

import java.util.List;

import egovframework.example.sample.vo.TestVo;

public interface TestDao {
	 public List<TestVo> selectTestList() throws Exception;
	 public List<TestVo> searchTest(TestVo testVo) throws Exception;
	 public TestVo selectTest(TestVo testVo) throws Exception;
	 public void addTest(TestVo testVo) throws Exception;
	 public void updateTest(TestVo testVo) throws Exception;
	 public void deleteTest(TestVo testVo) throws Exception;
	 public int countTest(TestVo testVo) throws Exception;
}
