package egovframework.example.sample.web;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import egovframework.example.sample.service.TestService;
import egovframework.example.sample.service.UserService;
import egovframework.example.sample.vo.TestVo;
import egovframework.example.sample.vo.UserVo;

@Controller
public class TestController {
	
	@Autowired
	private TestService testservice;
	@Autowired
	private UserService userservice;
	
	int totalPage;
	
	@RequestMapping(value="first.do")
	public String first(TestVo testVo, HttpServletRequest req,Model model,@RequestParam(value= "move_page", defaultValue = "0") int move_page) throws Exception{
		HttpSession session = req.getSession();
		if(session.getAttribute("user") != null) {
			model.addAttribute("list", testservice.selectTestList());	
			
			if(testservice.countTest(testVo) < 5) {
				totalPage=1;			
			}else if(testservice.countTest(testVo) % 5 == 0) {
				totalPage = testservice.countTest(testVo)/5;
			}
				
			else {
				totalPage =testservice.countTest(testVo)/5 +1 ;
			}
					
			model.addAttribute("totalPage", totalPage);
			model.addAttribute("currentPage", move_page);
			
			return "sample/board";
		}else {
			return "sample/login";
		}		
	}
	
	@RequestMapping(value="/login.do", method = RequestMethod.POST)
	public String login(UserVo userVo,TestVo testVo, HttpServletRequest req,Model model) throws Exception{
		UserVo loginVo = userservice.login(userVo);
		HttpSession session = req.getSession();
		model.addAttribute("list", testservice.selectTestList());
		
		if(session.getAttribute("user") != null) {
			return "forward:/first.do";	
		}
		else {
			if(loginVo == null) {
				model.addAttribute("state","falied");
				return "sample/login";
			}
			else {	
				session.setAttribute("user", loginVo);			
				return "forward:/first.do";				
			}	
		} 
	}
	
	@RequestMapping(value="/logout.do", method=RequestMethod.POST)
	public String logout(HttpSession session, Model model) throws Exception{
		session.invalidate(); //세션 초기화 
		return "redirect:/";
	}
	
	@RequestMapping(value="signupView.do")
	public String signupView() throws Exception{
		return "sample/signup";
	}
	@RequestMapping(value="signup.do", method=RequestMethod.POST)
	public String signup(UserVo userVo, Model model) throws Exception{
		if(userservice.findPwd(userVo) != null) {
			model.addAttribute("state","failed");
			return "sample/signup";
		}else {
			userservice.signup(userVo);
			return "sample/login";
		}
		
		
	}
	@RequestMapping(value="signout.do", method=RequestMethod.POST)
	public String signout(UserVo userVo, HttpSession session) throws Exception{
		session.invalidate(); //세션초기화 후 
		userservice.signout(userVo); //계정삭제 
		return "sample/login";
	}
	
	@RequestMapping(value="findPwd.do", method=RequestMethod.POST)
	public String findPwd(UserVo userVo, Model model) throws Exception {
		UserVo findUser = userservice.findPwd(userVo);
		if(findUser != null) {
			model.addAttribute("user", findUser);
			return "sample/login";
		}else {
			return "sample/login";
		}
		
	}
	@RequestMapping(value="addTestView.do", method=RequestMethod.POST)
	public String testRegister(TestVo testVo, Model model, HttpServletRequest req) throws Exception {
		testVo.setRegisterFlag("add");
		HttpSession session = req.getSession();
		UserVo userVo = (UserVo) session.getAttribute("user");
		model.addAttribute("userVo", userVo);
		model.addAttribute("testVo", testVo);
		return "sample/boardRegister";
		
	}
	@RequestMapping(value="addTest.do", method=RequestMethod.POST)
	public String testAdd(TestVo testVo, Model model) throws Exception {
		
		String fileName = null;
		MultipartFile uploadFile = testVo.getUploadFile();
		
		if(!uploadFile.isEmpty()) {
	         fileName = uploadFile.getOriginalFilename();
	         uploadFile.transferTo(new File("/usr/local/upload/" + fileName));
		}
		testVo.setFileName(fileName);
		
		testservice.addTest(testVo);
		model.addAttribute("list", testservice.selectTestList());
		return "forward:/login.do";
		
	}
	
	@RequestMapping(value="updateTestView.do", method=RequestMethod.POST)
	public String testUpdateView(UserVo userVo, TestVo testVo, Model model) throws Exception {
		testVo.setRegisterFlag("modify");
		model.addAttribute("testVo", testVo);
		return "sample/boardRegister";
		
	}
	
	@RequestMapping(value="updateTest.do", method=RequestMethod.POST)
	public String testUpdate(TestVo testVo, Model model) throws Exception {
		
		// 파일 업로드
        String fileName = null;
        MultipartFile uploadFile = testVo.getUploadFile();
        if (!uploadFile.isEmpty()) {
            fileName = uploadFile.getOriginalFilename();
            uploadFile.transferTo(new File("/usr/local/upload/" + fileName));
            testVo.setFileName(fileName);
        }      
        testservice.updateTest(testVo);
        return "forward:/login.do";
		
	}
	
	@RequestMapping(value="testSelect.do", method=RequestMethod.POST)
	public String selectTest(TestVo testVo, Model model) throws Exception {
		TestVo selectVo = testservice.selectTest(testVo);
		selectVo.setRegisterFlag("view");
		model.addAttribute("testVo", selectVo);
		
		return "sample/boardRegister";
	}
	
	@RequestMapping(value = "deleteTest.do", method=RequestMethod.POST)
	public String deleteTest(TestVo testVo) throws Exception {
		testservice.deleteTest(testVo);
		return "forward:/login.do";
	}
	@RequestMapping(value = "searchTest.do")
	public String searchTest(TestVo testVo, Model model,@RequestParam(value= "move_page", defaultValue = "0") int move_page) throws Exception{
		model.addAttribute("search",testVo.getSearch());
		model.addAttribute("list",testservice.searchTest(testVo));	
		
		if(testservice.countTest(testVo) < 5) {
			totalPage=1;			
		}else if(testservice.countTest(testVo) % 5 == 0)
			totalPage = testservice.countTest(testVo)/5;
		else
			totalPage =testservice.countTest(testVo)/5 +1 ;
		
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("currentPage", move_page);
		return "sample/board";
	}
	@RequestMapping(value = "mypageView.do")
	public String mypageView(HttpServletRequest req, Model model, @RequestParam(value = "state", defaultValue = "non") String state) throws Exception {
		HttpSession session = req.getSession();
		UserVo userVo = (UserVo) session.getAttribute("user");
		model.addAttribute("user",userVo);
		if(state == "success") {
			model.addAttribute("state",state);
		}else if(state=="failed") {
			model.addAttribute("state",state);
		}else {
			model.addAttribute("state",state);
		}
		return "sample/myPage";
	}
	@RequestMapping(value = "updateUser.do")
	public String updateUser(UserVo userVo, HttpServletRequest req) throws Exception {
		userservice.updateUser(userVo);
		HttpSession session = req.getSession();
		session.invalidate();
		return "forward:/first.do";
	}
}
