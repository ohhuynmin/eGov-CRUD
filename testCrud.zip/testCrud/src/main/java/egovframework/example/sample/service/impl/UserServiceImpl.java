package egovframework.example.sample.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.UserDao;
import egovframework.example.sample.service.UserService;
import egovframework.example.sample.vo.UserVo;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
    private UserDao userDao;
    
	@Override
    public UserVo login(UserVo userVo) throws Exception{
    	return userDao.login(userVo);
    }

	@Override
	public void signup(UserVo userVo) throws Exception{
		userDao.signup(userVo);
	}
	@Override
	public void signout(UserVo userVo) throws Exception{
		userDao.signout(userVo);
	}
	@Override
	public UserVo findPwd(UserVo userVo) throws Exception{
		return userDao.findPwd(userVo);
	}
	@Override
	public void updateUser(UserVo userVo) throws Exception{
		userDao.updateUser(userVo);
	}

}
