package egovframework.example.sample.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.dao.TestDao;
import egovframework.example.sample.service.TestMapper;
import egovframework.example.sample.vo.TestVo;

@Repository
public class TestDaoImpl implements TestDao{
 
   @Autowired
   private SqlSession sqlSession;
   
   @Override
    public List<TestVo> selectTestList() throws Exception {
    	TestMapper mapper = sqlSession.getMapper(TestMapper.class);
    	return mapper.selectTestList();
	}
   
   @Override
   public TestVo selectTest(TestVo testVo) throws Exception{
	   TestMapper mapper = sqlSession.getMapper(TestMapper.class);
	   return mapper.selectTest(testVo);
   }
   
   @Override
   public void addTest(TestVo testVo) throws Exception{
	   TestMapper mapper = sqlSession.getMapper(TestMapper.class);
	   mapper.addTest(testVo);
   }
   @Override
   public void updateTest(TestVo testVo) throws Exception{
	   TestMapper mapper = sqlSession.getMapper(TestMapper.class);
	   mapper.updateTest(testVo);
   }
   @Override
   public void deleteTest(TestVo testVo) throws Exception{
	   TestMapper mapper = sqlSession.getMapper(TestMapper.class);
	   mapper.deleteTest(testVo);
   }
   @Override
   public List<TestVo> searchTest(TestVo testVo) throws Exception{
	   TestMapper mapper = sqlSession.getMapper(TestMapper.class);
   		return mapper.searchTest(testVo);
   }
   @Override
   public int countTest(TestVo testVo) throws Exception{
	   TestMapper mapper = sqlSession.getMapper(TestMapper.class);
	   return mapper.countTest(testVo);
   }
}

