package egovframework.example.sample.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.dao.UserDao;
import egovframework.example.sample.service.UserMapper;
import egovframework.example.sample.vo.UserVo;

@Repository
public class UserDaoImpl implements UserDao {

    @Autowired
    private SqlSession sqlSession;
    
    UserMapper mapper;
    
	@Override
    public UserVo login(UserVo userVo) throws Exception{
		mapper = sqlSession.getMapper(UserMapper.class);
    	return mapper.login(userVo);
    }
	
	@Override
	public void signup(UserVo userVo) throws Exception{
		mapper = sqlSession.getMapper(UserMapper.class);
		mapper.signup(userVo);
	}
	@Override
	public void signout(UserVo userVo) throws Exception{
		mapper = sqlSession.getMapper(UserMapper.class);
		mapper.signout(userVo);
	}
	@Override
	public 	UserVo findPwd(UserVo userVo) throws Exception{
		mapper = sqlSession.getMapper(UserMapper.class);
		return mapper.findPwd(userVo);
	}
	@Override
	public void updateUser(UserVo userVo) throws Exception{
		mapper = sqlSession.getMapper(UserMapper.class);
		mapper.updateUser(userVo);
	}
}
